import React from "react"

const Head = () => {
  return (
    <>
    </>
  )
}

export default Head
